//
//  ViewController.swift
//  BigoClone
//
//  Created by Mac1 on 30/11/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

