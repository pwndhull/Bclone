//
//  SignInViewController.swift
//  BigoClone
//
//  Created by Mac1 on 30/11/20.
//

import UIKit

class SignInViewController: UIViewController {

    
    @IBOutlet weak var fbLoginImage: UIImageView!
    
    @IBOutlet weak var twitterLoginImage: UIImageView!
    
    @IBOutlet weak var mobileLoginImage: UIImageView!
    
    var email           : String = ""
    var password        : String = ""
    var cPassword       : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func emailTextField(_ sender: UITextField) {
        //        Email Validation and Alert for that
        isValidEmail(email: sender.text!) ? self.email =  sender.text! : (self.Alert(validationStatus: 4))
    
        
    }
    
    
    @IBAction func PasswordTextField(_ sender: UITextField) {
        sender.isSecureTextEntry = true
        isValidPassword(passsword: sender.text!) ? self.email =  sender.text! : (self.Alert(validationStatus: 5))
        self.password =  sender.text!
        
    }
    
    @IBAction func confirmPasswordTextField(_ sender: UITextField) {
        sender.isSecureTextEntry = true
        self.cPassword = sender.text!
        
    }
    @IBAction func signUpActionBtn(_ sender: UIButton) {
        var validationStatus = 0
         email.isEmpty ? password.isEmpty ? (validationStatus = 3) : (validationStatus = 1) :  password.isEmpty ? (validationStatus = 2): password.isEmpty ? (validationStatus = 2) : (validationStatus = 0)
        
        self.Alert(validationStatus: validationStatus)
         
    
    }
    @IBAction func backToLogin(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func isValidEmail(email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func isValidPassword(passsword: String) -> Bool {
        let passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{6,20}$"
        let passPred = NSPredicate(format:"SELF MATCHES %@", passwordRegex)
        return passPred.evaluate(with: passsword)
        
    }
    
    func Alert(validationStatus: Int ) {
        
        switch validationStatus {
        case 0:
            let dialogMessage = UIAlertController(title: "Successfull", message: "Signed Up Successfullt", preferredStyle: .alert)
             
             // Create OK button with action handler
             let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

                let secondViewController = storyBoard.instantiateViewController(withIdentifier: "TBC") as! UITabBarController
                self.present(secondViewController, animated:true, completion:nil)

             
             })
             
             //Add OK button to a dialog message
             dialogMessage.addAction(ok)
             // Present Alert to
             self.present(dialogMessage, animated: true, completion: nil)
        case 1:
            let dialogMessage = UIAlertController(title: "Alert", message: "Email is empty.", preferredStyle: .alert)
             
             // Create OK button with action handler
             let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                 print("Ok button tapped")
              })
             
             //Add OK button to a dialog message
             dialogMessage.addAction(ok)
             // Present Alert to
             self.present(dialogMessage, animated: true, completion: nil)
            
        case 2:
        
            let dialogMessage = UIAlertController(title: "Alert", message: "Password is empty", preferredStyle: .alert)
             
             // Create OK button with action handler
             let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                 print("Ok button tapped")
              })
             
             //Add OK button to a dialog message
             dialogMessage.addAction(ok)
             // Present Alert to
             self.present(dialogMessage, animated: true, completion: nil)
        case 3:
            let dialogMessage = UIAlertController(title: "Alert", message: "Email and Password is empty", preferredStyle: .alert)
             
             // Create OK button with action handler
             let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                 print("Ok button tapped")
              })
             
             //Add OK button to a dialog message
             dialogMessage.addAction(ok)
             // Present Alert to
             self.present(dialogMessage, animated: true, completion: nil)
        case 4:
            let dialogMessage = UIAlertController(title: "Alert", message: "Email is not valid", preferredStyle: .alert)
             
             // Create OK button with action handler
             let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                 print("Ok button tapped")
              })
             
             //Add OK button to a dialog message
             dialogMessage.addAction(ok)
             // Present Alert to
             self.present(dialogMessage, animated: true, completion: nil)
        case 5:
            let dialogMessage = UIAlertController(title: "Alert", message: "Password is not valid", preferredStyle: .alert)
            
            // Create OK button with action handler
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
            })
            
            //Add OK button to a dialog message
            dialogMessage.addAction(ok)
            // Present Alert to
            self.present(dialogMessage, animated: true, completion: nil)
        default:
            break
        }
    }
    
    
    
    
    
    
    
}
