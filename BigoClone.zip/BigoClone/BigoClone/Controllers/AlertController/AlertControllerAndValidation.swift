//
//  AlertController.swift
//  BigoClone
//
//  Created by Mac1 on 30/11/20.
//


//MARK:- class for common methods
import  UIKit
class Validation {
    
    public func isValidEmail(email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    public func isValidPassword(passsword: String) -> Bool {
        let passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{8,}$"
//        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: self)
        let passPred = NSPredicate(format: "SELF MATCH %@", passwordRegex)
        return passPred.evaluate(with: passsword)
        
    }
}
