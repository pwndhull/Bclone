//
//  InboxVCTableViewController.swift
//  BigoClone
//
//  Created by Mac1 on 01/12/20.
//

import UIKit

class InboxTableVC: UIViewController {
   
    @IBOutlet weak var mTableView: UITableView!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
   

   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension InboxTableVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell        : MessageCell!
        cell            = tableView.dequeueReusableCell(withIdentifier: "MessageCell") as? MessageCell
        
        cell.senderName?.text       = "Lorem Ipsum"
//        cell.SenderImage.image = UIImage(name: )
        cell.messageText?.text      =  "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
        return cell

        }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }


}
