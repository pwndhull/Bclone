//
//  FriendListVC.swift
//  BigoClone
//
//  Created by Mac1 on 01/12/20.
//

import UIKit

class FriendListVC: UIViewController {

    @IBOutlet weak var FriendListTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backBarBtnAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
}

extension FriendListVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : FriendListCellTableViewCell!
        cell = tableView.dequeueReusableCell(withIdentifier: "FriendListIdentifier") as? FriendListCellTableViewCell
        
        cell.friendName.text = "Pawan Dhull"
        cell.friendImage.image = UIImage(named: "Sender")
        
    return cell
        
    }
    
    
}
