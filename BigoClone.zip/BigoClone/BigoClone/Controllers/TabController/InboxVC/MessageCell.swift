//
//  Message.swift
//  BigoClone
//
//  Created by Mac1 on 01/12/20.
//

import UIKit

class MessageCell: UITableViewCell {

    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var senderName: UILabel!
    
    @IBOutlet weak var messageText: UILabel!
    
    @IBOutlet weak var SenderImage: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
