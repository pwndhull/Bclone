//
//  SegmentViewController.swift
//  BigoClone
//
//  Created by Balvinder on 05/12/20.
//

import UIKit
import Segmentio
class SegmentViewController: UIViewController {
    
    @IBOutlet weak var segmentioView: Segmentio!
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    var PostVC = UIViewController()
    
    private lazy var viewControllers: [UIViewController] = {
        return self.preparedViewControllers()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.scrollView.delegate = self
        
        // Do any additional setup after loading the view.
        self.setupSegmentioView()
        self.setupScrollView()
        
        
    }
    
    private func preparedViewControllers() -> [UIViewController] {
        
        // Set up base controllers
        let firstSegment            = self.storyboard?.instantiateViewController(withIdentifier: "PostsVC") as! PostsVC
        let secondSegment           = self.storyboard?.instantiateViewController(withIdentifier: "PostsVC") as! PostsVC
        let ThirdSegment           = self.storyboard?.instantiateViewController(withIdentifier: "FollowVC") as! FollowedViewController
        return [firstSegment , secondSegment,ThirdSegment]
        
        
        
    }
    private func setupScrollView() {
        scrollView.contentSize = CGSize(
            width: UIScreen.main.bounds.width * CGFloat(viewControllers.count),
            height: containerView.frame.height
        )
        
        for (index, viewController) in viewControllers.enumerated() {
            viewController.view.frame = CGRect(
                x:UIScreen.main.bounds.width * CGFloat(index),
                y: 0,
                width: containerView.frame.width,
                height: containerView.frame.height
            )
            addChild(viewController)
            scrollView.addSubview(viewController.view)
            viewController.didMove(toParent: self)
        }
    }
    
    private func setupSegmentioView() {
        let segmentioIndicatorOptions : SegmentioIndicatorOptions = SegmentioIndicatorOptions(
            type: .bottom, ratio: 1, height: 2, color: .black
        )
        let segmentioHoriZontalSeperationOptions : SegmentioHorizontalSeparatorOptions = SegmentioHorizontalSeparatorOptions(
            type: SegmentioHorizontalSeparatorType.top, height: 1, color: .gray
        )
        
        let segmentioVerticalSeparatorOptions :SegmentioVerticalSeparatorOptions   = SegmentioVerticalSeparatorOptions(
            ratio: 0,
            color: .gray
        )
        
        let segmentioStates :SegmentioStates   = SegmentioStates(
            defaultState: SegmentioState(
                backgroundColor: .clear,
                titleFont: UIFont.boldSystemFont(ofSize: 13.0),
                titleTextColor: .white
            ),
            selectedState: SegmentioState(
                backgroundColor: .clear,
                titleFont: UIFont.boldSystemFont(ofSize: 13.0),
                titleTextColor: .white
            ),
            highlightedState: SegmentioState(
                backgroundColor: UIColor.lightGray.withAlphaComponent(0.6),
                titleFont: UIFont.boldSystemFont(ofSize: 13.0),
                titleTextColor: .white
            )
        )
        let segmentOptions : SegmentioOptions    = SegmentioOptions(backgroundColor: #colorLiteral(red: 0.4470588235, green: 0, blue: 0.5960784314, alpha: 1) , segmentPosition: SegmentioPosition.fixed(maxVisibleItems: 3), scrollEnabled: true, indicatorOptions: segmentioIndicatorOptions, horizontalSeparatorOptions: segmentioHoriZontalSeperationOptions, verticalSeparatorOptions: segmentioVerticalSeparatorOptions, imageContentMode: .bottomLeft, labelTextAlignment: .center, labelTextNumberOfLines: 2, segmentStates: segmentioStates, animationDuration: 0.3)
        
        let segmentioItem1 : SegmentioItem  = SegmentioItem(title: "Hot", image: UIImage(named: "Cross"))
        let segmentioItem2 : SegmentioItem  = SegmentioItem(title: "New", image: UIImage(named: "Cross"))
        let segmentioItem3 : SegmentioItem  = SegmentioItem(title: "Followed", image: UIImage(named: "Cross"))
        
        segmentioView.setup(
            content: [segmentioItem1 , segmentioItem2, segmentioItem3],
            style: SegmentioStyle.onlyLabel,
            options: segmentOptions
        )
        
        segmentioView.selectedSegmentioIndex = 0
        self.goToControllerAtIndex(0)
        
        segmentioView.valueDidChange = { segmentio, segmentIndex in
            print("Selected item: ", segmentIndex)
            let scrollViewWidth     = self.scrollView.frame.width
            let contentOffsetX      = scrollViewWidth * CGFloat(segmentIndex)
            self.scrollView.setContentOffset(CGPoint(x: contentOffsetX, y: 0), animated: true )
            self.goToControllerAtIndex(segmentIndex)
        }
        
        
    }
    //    @objc func filter() {
    //        self.view.endEditing(true)
    //        print("Filter Action Clicked")
    //
    //        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FilterJobVC") as! FilterJobVC
    //        vc.delegate = (findJobVC as! FilterIndexDelegate)
    //        self.navigationController?.present(vc, animated: false, completion: {
    //            // self.tabBarController?.tabBar.isUserInteractionEnabled = false
    //        })
    //
    //    }
    
    private func goToControllerAtIndex(_ index: Int) {
        segmentioView.selectedSegmentioIndex = index
        
        //            if segmentioView.selectedSegmentioIndex == 0 {
        //                self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Filter", style: .plain, target: self, action: #selector(filter))
        //            } else {
        //                self.navigationItem.rightBarButtonItem  = nil
        //            }
    }
    
}
extension SegmentViewController: UIScrollViewDelegate  {
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let currentPage = floor(scrollView.contentOffset.x / scrollView.frame.width)
        segmentioView.selectedSegmentioIndex = Int(currentPage)
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        scrollView.contentSize = CGSize(width: scrollView.contentSize.width, height: 0)
    }
}
