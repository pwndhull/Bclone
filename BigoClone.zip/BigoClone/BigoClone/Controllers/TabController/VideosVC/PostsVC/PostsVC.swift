//
//  PostsVC.swift
//  BigoClone
//
//  Created by Balvinder on 03/12/20.
//

import Foundation
import UIKit

class PostsVC: UIViewController {
    
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var AddButton: UIButton!
    
    
    @IBOutlet weak var cameraBTN: UIButton!
    @IBOutlet weak var gallaryBTN: UIButton!
    @IBOutlet weak var videoBTN: UIButton!
    var floatingBtnStatus = true
    var size = 505
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupAddAction(isHidden: true)
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        
    }
    
    func setupAddAction(isHidden : Bool) {
        if !isHidden {
            self.cameraBTN.isHidden         = false
            self.gallaryBTN.isHidden        = false
            self.videoBTN.isHidden          = false
        }else {
            self.cameraBTN.isHidden         = true
            self.gallaryBTN.isHidden        = true
            self.videoBTN.isHidden          = true
        }
    }
    func setStateForBTN()  -> Bool {
        self.floatingBtnStatus ? (self.floatingBtnStatus = false) : (floatingBtnStatus = true)
        return floatingBtnStatus
    }
    
    @IBAction func AddBtnAction(_ sender: UIButton) {
        let isHidden = setStateForBTN()
        self.setupAddAction(isHidden: isHidden)
    }
    
    
    
}
    
    
    

extension PostsVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell        : PostsCellTableViewCell!
        cell            = tableView.dequeueReusableCell(withIdentifier: "PostCell") as? PostsCellTableViewCell
        cell?.userName.text          = "Lorem Ipsum"
        cell?.userBio.text           = "Nothing"
        cell.userImage.image         = UIImage(named: "Sender")
        cell.userImage.layer.cornerRadius = 25
        cell.userImage.layer.borderWidth = 2
        cell.userImage.layer.borderColor = CGColor.init(red: 220, green: 220, blue: 220, alpha: 1) // UIColor.black
        
        cell.postText.text           = "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
    
        cell.postImage.image         = UIImage(named: "Posts")
        cell.postTime.text           = "10 min(s) ago"
        
        cell.postTime.isEnabled = false
        cell.isUserInteractionEnabled = false
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
        return 510
    }
    
    
}

