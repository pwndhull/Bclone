//
//  FollowedTableViewCell.swift
//  BigoClone
//
//  Created by Balvinder on 07/12/20.
//

import UIKit

class FollowedTableViewCell: UITableViewCell {


    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var userBio: UILabel!
    
    @IBOutlet weak var userImage: UIImageView!
    
    @IBOutlet weak var followBtn: UIButton!
    
    
    @IBOutlet weak var postText: UILabel!
    @IBOutlet weak var postImage: UIImageView!
    
    
    @IBOutlet weak var postTime: UILabel!
    
    
    
    @IBOutlet weak var moreBtn: UIButton!
    @IBOutlet weak var commentBtn: UIButton!
    @IBOutlet weak var likeBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
    }

    @IBAction func followBtnAction(_ sender: UIButton) {
        
    }
    
    
    @IBAction func likeBtnAction(_ sender: UIButton) {
        
    }
    
    @IBAction func commentBtnAction(_ sender: UIButton) {
        
    }
    
    @IBAction func moreActionBtn(_ sender: UIButton) {
        
    }
}
