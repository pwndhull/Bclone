//
//  LiveViewController.swift
//  BigoClone
//
//  Created by Balvinder on 03/12/20.
//

import UIKit

class LiveViewController: UIViewController, UIImagePickerControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.'
        self.OpenCamera()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func OpenCamera(){
        let cameraVc = UIImagePickerController()
        cameraVc.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(cameraVc, animated: true, completion: nil)
    }
    
    
    
}
