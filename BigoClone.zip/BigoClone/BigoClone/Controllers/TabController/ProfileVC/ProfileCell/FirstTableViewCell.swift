//
//  FirstTableViewCell.swift
//  BigoClone
//
//  Created by Balvinder on 14/12/20.
//

import UIKit

class FirstTableViewCell: UITableViewCell {

    @IBOutlet weak var beandLbl: UILabel!
    
    @IBOutlet weak var beansBtn: UIButton!
    @IBOutlet weak var diamondLbl: UILabel!
    
    @IBOutlet weak var diamondBtn: UIButton!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func beansBtnAction(_ sender: Any) {
        print("beans Clicked")
    }
    
    
    @IBAction func diamondBtnAction(_ sender: Any) {
        print("diamond Clicked")
    }
    

}
