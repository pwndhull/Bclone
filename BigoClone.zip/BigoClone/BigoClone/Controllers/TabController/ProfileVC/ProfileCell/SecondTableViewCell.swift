//
//  SecondTableViewCell.swift
//  BigoClone
//
//  Created by Balvinder on 14/12/20.
//

import UIKit

class SecondTableViewCell: UITableViewCell {

    @IBOutlet weak var friendsLbl: UILabel!
    
    @IBOutlet weak var followersLbl: UILabel!
    
    @IBOutlet weak var followingLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func friendsBtnAction(_ sender: Any) {
        print("Friend Button Pressed")
    }
    
    @IBAction func followersBtnAction(_ sender: Any) {
        print("Follower Button Pressed")
    }
    
    @IBAction func followingBtnAction(_ sender: Any) {
        print("Following Button Pressed")
    }
}
