//
//  FollowersViewController.swift
//  BigoClone
//
//  Created by Balvinder on 09/12/20.
//

import UIKit

class FollowersViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

extension FollowersViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : FollowerTableViewCell!
        
        cell = tableView.dequeueReusableCell(withIdentifier: "FollowersVCCell") as? FollowerTableViewCell
        cell.FlImage.image = UIImage(named: "Sender")
        cell.FlName.text = "Test Following"
        cell.FlLastOnlineDetails.text = "Last Online: 32m ago"
        
        return cell
    }
    
    
    
    
    
}
