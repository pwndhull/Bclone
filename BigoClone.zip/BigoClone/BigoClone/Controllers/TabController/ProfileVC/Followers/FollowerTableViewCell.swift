//
//  FollowerTableViewCell.swift
//  BigoClone
//
//  Created by Balvinder on 09/12/20.
//

import UIKit

class FollowerTableViewCell: UITableViewCell {

    @IBOutlet weak var FlImage: UIImageView!
    @IBOutlet weak var FlName: UILabel!
    @IBOutlet weak var FlLastOnlineDetails: UILabel!
    @IBOutlet weak var FlLvl: UIImageView!
    @IBOutlet weak var FlBadge: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
