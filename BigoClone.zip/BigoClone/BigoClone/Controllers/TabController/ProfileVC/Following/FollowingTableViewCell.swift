//
//  FollowingTableViewCell.swift
//  BigoClone
//
//  Created by Balvinder on 09/12/20.
//

import UIKit

class FollowingTableViewCell: UITableViewCell {

    @IBOutlet weak var fImage: UIImageView!
    
    @IBOutlet weak var fName: UILabel!
    @IBOutlet weak var lastOnlineDetail: UILabel!
    
    @IBOutlet weak var userLvl: UIImageView!
    
    @IBOutlet weak var userBadge: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
