//
//  FollowingViewController.swift
//  BigoClone
//
//  Created by Balvinder on 09/12/20.
//

import UIKit

class FollowingViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tblView.delegate           = self
        self.tblView.dataSource         = self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension FollowingViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : FollowingTableViewCell!
        
        cell = tableView.dequeueReusableCell(withIdentifier: "FollowingVCCell") as? FollowingTableViewCell
//        cell.fImage.image = UIImage(named: "Sender")
//        cell.fName.text = "Test Following"
//        cell.lastOnlineDetail.text = "Last Online: 32m ago"
        
        return cell
    }
    
    
    
    
    
}
