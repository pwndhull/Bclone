//
//  ProfileVCTBL.swift
//  BigoClone
//
//  Created by Balvinder on 14/12/20.
//

import UIKit

class ProfileVCTBL: UIViewController {
    
    @IBOutlet weak var userProfile  : UIImageView!
    @IBOutlet weak var tblView      : UITableView!
    @IBOutlet weak var userName     : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate       = self
        self.tblView.dataSource     = self
        
    }
    
    
    
    
    
}

extension ProfileVCTBL : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (indexPath.row == 0){
            let cell:FirstTableViewCell = tableView.dequeueReusableCell(withIdentifier: "FirstTableViewCell") as! FirstTableViewCell
            cell.beandLbl.text = "0"
            cell.diamondLbl.text = "0"
            cell.selectionStyle = .none
            return cell
        } else if (indexPath.row == 1 ){
            let cell:SecondTableViewCell = tableView.dequeueReusableCell(withIdentifier: "SecondTableViewCell") as! SecondTableViewCell
            cell.followingLbl.text = "0"
            cell.followersLbl.text = "20"
            cell.friendsLbl.text = "0"
            cell.selectionStyle = .none

            return cell
        }else if (indexPath.row == 2 ){
            let cell:ThirdTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ThirdTableViewCell") as! ThirdTableViewCell
            cell.selectionStyle = .none
            return cell
        }else if (indexPath.row == 3 ){
            let cell:FourthTableViewCell = tableView.dequeueReusableCell(withIdentifier: "FourthTableViewCell") as! FourthTableViewCell
            cell.selectionStyle = .none
            return cell
        }else if (indexPath.row == 4 ){
            let cell:FifthTableViewCell = tableView.dequeueReusableCell(withIdentifier: "FifthTableViewCell") as! FifthTableViewCell
            cell.selectionStyle = .none
            return cell
        }else if (indexPath.row == 5 ){
            let cell:SixthTableViewCell = tableView.dequeueReusableCell(withIdentifier: "SixthTableViewCell") as! SixthTableViewCell
            cell.selectionStyle = .none
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var height = 50
        if (indexPath.row == 0) {
            height = 71
        } else if (indexPath.row == 1){
            height = 60
        } else if (indexPath.row == 2) || (indexPath.row == 3) || (indexPath.row == 4) || (indexPath.row == 5) {
            height = 70
        }
        return CGFloat(height)
    }
    
    @objc func BeansClicked(){
        print("Beans Clicked")
    }
    
}
